//
//  kPersistent.c
//  AROMA_XCODE
//
//

#include "kPersistent.h"

int HashTableInsert(HashTable*** ht, char* FlowLabel, char* ElementID, int RowIndex, int Random[]){
    assert(ht);
    // Allocate buffer to hold concatenated strings
    char* buffer = (char*) malloc(sizeof(char) * (strlen(FlowLabel) + strlen(ElementID)));
    if(!buffer){
        return 0;
    }
    // Concatenate strings
    strcpy(buffer, FlowLabel);
    strcat(buffer, ElementID);
    
    int Hash = IntHash(FNVHash1(buffer) ^ Random[0]);
    int index = (Hash % (*ht)[0]->HashTableCapacity + (*ht)[0]->HashTableCapacity) % (*ht)[0]->HashTableCapacity;
    
    int hash_value = IntHash(FNVHash1(buffer) ^ Random[1]);
    float hashvalue = (float)((double) hash_value - (double) INT_MIN) / ((double) (INT_MAX + 1.0) * 2.0);
    
    if ((*ht)[RowIndex]->hashtable[index].FlowLabel != NULL){
        if ((*ht)[RowIndex]->hashtable[index].HashValue > hashvalue){
            strcpy((*ht)[RowIndex]->hashtable[index].FlowLabel, FlowLabel);
            strcpy((*ht)[RowIndex]->hashtable[index].ElementID, ElementID);
            (*ht)[RowIndex]->hashtable[index].HashValue = hashvalue;
        }
    }
    else{
        (*ht)[RowIndex]->hashtable[index].FlowLabel = strdup(FlowLabel);
        (*ht)[RowIndex]->hashtable[index].ElementID = strdup(ElementID);
        (*ht)[RowIndex]->hashtable[index].HashValue = hashvalue;
    }
    free(buffer);
    return 0;
}

void HashTableMerge(HashTable*** ht, int Row){
    HTMerge = (HashTable*) malloc (sizeof(HashTable));
    assert(HTMerge);
    HTMerge->hashtable = (HashNode*) malloc (sizeof(HashNode) * (*ht)[0]->HashTableCapacity);
    if (HTMerge->hashtable == NULL){
        perror("use malloc to create");
    }
    HTMerge->HashTableCapacity = (*ht)[0]->HashTableCapacity;
    HTMerge->HashTableSizeCurrent = 0;
    HTMerge->SumOfHashValue = 0;
    HTMerge->SumOfNonNULL = 0;

    for (int i = 0; i < HTMerge->HashTableCapacity; i++){
        float MinHashValue = FLT_MAX;
        int MinRowIndex = 0;
        int Flag = 1;
        for (int j = 0; j < Row; j++){
            if ((*ht)[j]->hashtable[i].FlowLabel != NULL && (*ht)[j]->hashtable[i].HashValue < MinHashValue){
                MinHashValue = (*ht)[j]->hashtable[i].HashValue;
                MinRowIndex = j;
                Flag = 0;
            }
        }
        if (Flag == 0){
            HTMerge->hashtable[i].FlowLabel = strdup((*ht)[MinRowIndex]->hashtable[i].FlowLabel);
            HTMerge->hashtable[i].ElementID = strdup((*ht)[MinRowIndex]->hashtable[i].ElementID);
            HTMerge->hashtable[i].HashValue = (*ht)[MinRowIndex]->hashtable[i].HashValue;
        }

        if (HTMerge->hashtable[i].FlowLabel != NULL){
            HTMerge->HashTableSizeCurrent++;
            HTMerge->SumOfHashValue += HTMerge->hashtable[i].HashValue;
            HTMerge->SumOfNonNULL++;
        }
        else{
            HTMerge->SumOfHashValue += 1.0;
        }
    }
}

void PrintHashTable(HashTable*** ht, int Row){
    assert(ht);
    for (int j = 0; j < Row; j++){
        for (int i = 0; i < (*ht)[j]->HashTableCapacity; i++){
            if ((*ht)[j]->hashtable[i].FlowLabel != NULL){
                printf("[%d][%d](%s:%s)[%f]\n", j, i, (*ht)[j]->hashtable[i].FlowLabel, (*ht)[j]->hashtable[i].ElementID, (*ht)[j]->hashtable[i].HashValue);
            }
        }
        printf("\n");
    }
}

void HashTableMergeDestroy(HashTable* ht){
    assert(ht);
    free(ht->hashtable);
    ht->hashtable = NULL;
    ht->HashTableCapacity = 0;
    ht->HashTableSizeCurrent = 0;
    ht->SumOfHashValue = 0;
    ht->SumOfNonNULL = 0;
}

void PrintHashTableMerge(HashTable* HTMerge){
    assert(HTMerge);
    for (int i = 0; i < HTMerge->HashTableCapacity; i++){
        if (HTMerge->hashtable[i].FlowLabel != NULL){
            printf("[%d](%s:%s)[%f]\n", i, HTMerge->hashtable[i].FlowLabel, HTMerge->hashtable[i].ElementID, HTMerge->hashtable[i].HashValue);
        }
    }
        printf("\n");
}

float* EstimatedKSpread(HashTable*** ht, HashTable* HTMerge, char* FlowLabel, int Row){
    int SpreadCountArray[Row];
    
    float* EstimatedKSpread = (float*) malloc (sizeof(float) * Row);
    if (EstimatedKSpread == NULL) {
        return NULL;
    }
    
    for (int i = 0; i< Row; i++){
        SpreadCountArray[i] = 0;
        EstimatedKSpread[i] = 0;
    }

    double SumOfHashValue = HTMerge->SumOfHashValue;
    int SumOfNonNULL = HTMerge->SumOfNonNULL; // S
    int SumOfFlow = 0;    // sf
    int SumOfSpread = 0;
    
    for (int i = 0; i < HTMerge->HashTableCapacity; i++){
        if (HTMerge->hashtable[i].FlowLabel != NULL && strcmp(HTMerge->hashtable[i].FlowLabel, FlowLabel) == 0){
                int SpreadCount = 0;
                SumOfFlow++;
                for (int j = 0; j < Row; j++){
                    if((*ht)[j]->hashtable[i].FlowLabel != NULL){
                        if (strcmp((*ht)[j]->hashtable[i].FlowLabel, HTMerge->hashtable[i].FlowLabel) == 0 && strcmp((*ht)[j]->hashtable[i].ElementID, HTMerge->hashtable[i].ElementID) == 0){
                            SpreadCount++;
                        }
                    }
                }
                SpreadCountArray[SpreadCount - 1]++;
        }
    }

    for (int i = Row - 1; i >= 0; i--){
        SumOfSpread += SpreadCountArray[i];
        SpreadCountArray[i] = SumOfSpread;
    }
    
    if (SumOfSpread == 0){
        return EstimatedKSpread;
    }
    
    float EstimatedNumOfFlow = (float)(((double)HTMerge->HashTableCapacity) * ((double)HTMerge->HashTableCapacity) / ((double)SumOfHashValue));

    for (int i = 0; i < Row; i++){
        EstimatedKSpread[i] = (SpreadCountArray[i] / SumOfSpread) * (SumOfFlow * EstimatedNumOfFlow / SumOfNonNULL);
    }
   
    return EstimatedKSpread;
}




//float EstimatedKSpread(HashTable*** ht, HashTable* HTMerge, char* FlowLabel, int Row, int K){
//    float EstimatedKSpread = 0;
//
//    int SpreadCountArray[Row + 1];
//    for (int i = 0; i< Row + 1; i++){
//        SpreadCountArray[i] = 0;
//    }
//
//    float EstimatedNumOfFlow = 0;
//    long SumOfHashValue = 0;
//    int SumOfNonNULL = 0; // S
//    int SumOfFlow = 0;    // sf
//
//    // memset(SpreadCountArray, 0, sizeof(SpreadCountArray));
//    int SumOfSpread = 0;
//    int SumOfKSpread = 0;
//
//    for (int i = 0; i < HTMerge->HashTableCapacity; i++){
//        if (HTMerge->hashtable[i].FlowLabel != NULL){
//            SumOfNonNULL++; // S
//            SumOfHashValue += HTMerge->hashtable[i].HashValue;
//            if (strcmp(HTMerge->hashtable[i].FlowLabel, FlowLabel) == 0){
//                int SpreadCount = 0;
//                SumOfFlow++; // sf
//                for (int j = 0; j < Row; j++){
//                    if((*ht)[j]->hashtable[i].FlowLabel != NULL && strcmp((*ht)[j]->hashtable[i].ElementID, HTMerge->hashtable[i].ElementID) == 0){
//                        SpreadCount++;
//                    }
//                }
//                SpreadCountArray[SpreadCount]++;
//            }
//        }
//    }
//    EstimatedNumOfFlow = pow(HTMerge->HashTableCapacity, 2) * UINT32_MAX / SumOfHashValue;
//    // return SumOfFlow * EstimatedNumOfFlow / SumOfNonNULL;
//
//    for (int i = 1; i < Row; i++){
//        SumOfSpread += SpreadCountArray[i];
//        if (i >= K){
//            SumOfKSpread += SpreadCountArray[i];
//        }
//    }
//    if (SumOfSpread == 0){
//        return 0;
//    }
//
//   // return SpreadCountArray[K - 1] / SumOfSpread;
//
//    EstimatedKSpread = SumOfKSpread / SumOfSpread * SumOfFlow * EstimatedNumOfFlow / SumOfNonNULL;
//
//    return EstimatedKSpread;
//}





//float EstimatedSpreadOfFlow(HashTable* HTMerge, char* FlowLabel){
//    float EstimatedNumOfFlow = 0;
//    long SumOfHashValue = 0;
//    int SumOfNonNULL = 0; // S
//    int SumOfFlow = 0;    // sf
//    for (int i = 0; i < HTMerge->HashTableCapacity; i++){
//        if (HTMerge->hashtable[i].FlowLabel != NULL){
//            SumOfNonNULL++;
//            SumOfHashValue += HTMerge->hashtable[i].HashValue;
//            if (strcmp(HTMerge->hashtable[i].FlowLabel, FlowLabel) == 0){
//                SumOfFlow++;
//            }
//        }
//    }
//    EstimatedNumOfFlow = pow(HTMerge->HashTableCapacity, 2) * UINT32_MAX / SumOfHashValue;
//    return SumOfFlow * EstimatedNumOfFlow / SumOfNonNULL;
//}
//
//float EstimatedKSpreadOfFlow(HashTable*** ht, HashTable* HTMerge, char* FlowLabel, int Row, int K){
//    int SpreadCountArray[Row];
//    memset(SpreadCountArray, 0, Row);
//    int SumOfSpread = 0;
//    for (int i = 0; i < HTMerge->HashTableCapacity; i++){
//        if (HTMerge->hashtable[i].FlowLabel != NULL && strcmp(HTMerge->hashtable[i].FlowLabel, FlowLabel) == 0){
//            //if (strcmp(HTMerge->hashtable[i].FlowLabel, FlowLabel) == 0){
//                int SpreadCount = 0;
//                for (int j = 0; j < Row; j++){
//                    if ((*ht)[j]->hashtable[i].FlowLabel != NULL && strcmp((*ht)[j]->hashtable[i].ElementID, HTMerge->hashtable[i].ElementID) == 0){
//                        SpreadCount++;
//                    }
//                }
//                SpreadCountArray[SpreadCount - 1]++;
//            //}
//        }
//    }
//    for (int i = 0; i < Row; i++){
//        SumOfSpread += SpreadCountArray[i];
//    }
//    if (SumOfSpread == 0){
//        return 0;
//    }
//    return SpreadCountArray[K - 1] / SumOfSpread;
//}
