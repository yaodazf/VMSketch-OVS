#ifndef SKETCH_MANAGE_H
#define SKETCH_MANAGE_H


// #include "sketch_util.h"
#include "kPersistent.h"

void HashTableInit(HashTable*** ht, int HashTableCapacity, int Row);
void HashTableDestroy(HashTable*** ht, int Row)
void my_label_sketch(char* FlowLabel, char* ElementID);
// int init_LRU (int LRU_Capacity);
// void clean_LRU(void);
// void my_label_sketch( char* key);
#endif
