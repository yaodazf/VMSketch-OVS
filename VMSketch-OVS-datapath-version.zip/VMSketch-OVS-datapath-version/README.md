# ovs-datapath
This repository is a part of [ovs](https://github.com/zhangml/ovs.git), it cannot compile unless it is put in the ovs directory. This repository was made only for convenient, to prevent cloning the entire ovs repo and load them to the code editor.
Compilation environment is ubuntu 16.04 and openvswitch-2.10.2

# License
Follows the license of [ovs](https://github.com/zhangml/ovs.git).
