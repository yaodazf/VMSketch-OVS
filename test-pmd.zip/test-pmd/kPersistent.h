//
//  kPersistent.h
//  AROMA_XCODE
//
//

#ifndef kPersistent_h
#define kPersistent_h

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <assert.h>
#include <limits.h>
#include <float.h>

#include "GeneralHash.h"

//Record FlowLabel and ElementID
typedef struct{
    char* FlowLabel;
    char* ElementID;
    float HashValue;
} HashNode;

typedef struct {
    HashNode* hashtable;  // array of hash table
    int HashTableCapacity;
    int HashTableSizeCurrent;
    float SumOfHashValue;
    int SumOfNonNULL; // S
} HashTable;

HashTable** HT;
HashTable* HTMerge;
int Random[2];
// int RowIndex = 0;

//Init HashTable
void HashTableInit(HashTable*** ht, int HashTableCapacity, int Row);

//Detroy HashTable(memory of malloc)
void HashTableDestroy(HashTable*** ht, int Row);

//Insert HashTable
int HashTableInsert(HashTable*** ht, char* FlowLabel, char* ElementID, int RowIndex, int Random[]);

//Print Data in HashTable
void PrintHashTable(HashTable*** ht, int Row);

//Merge t period HashTable
void HashTableMerge(HashTable*** ht, int Row);

void HashTableMergeDestroy(HashTable* ht);

void PrintHashTableMerge(HashTable* ht);

//float EstimatedSpreadOfFlow(HashTable* HTMerge, char* FlowLabel);
//
//float EstimatedKSpreadOfFlow(HashTable*** ht, HashTable* HTMerge, char* FlowLabel, int Row, int K);

float* EstimatedKSpread(HashTable*** ht, HashTable* HTMerge, char* FlowLabel, int Row);

//float EstimatedKSpread(HashTable*** ht, HashTable* HTMerge, char* FlowLabel, int Row, int K);

void my_label_sketch(char* FlowLabel, char* ElementID);

#endif /* kPersistent_h */
