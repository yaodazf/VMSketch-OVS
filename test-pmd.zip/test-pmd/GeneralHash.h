//
//  GeneralHash.h
//  AROMA_XCODE
//
//

#ifndef GeneralHash_h
#define GeneralHash_h

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/** a hash function that maps the string value to int value */
int FNVHash1(char* data);

int IntHash(long key); // by Thomas Wang

#endif /* GeneralHash_h */
